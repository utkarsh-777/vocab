module.exports = {
    application_id:process.env.APPLICATION_ID,
    application_keys:process.env.APPLICATION_KEYS,
    base_url:process.env.BASE_URL,
    mongo_uri:process.env.MONGO_URI
}