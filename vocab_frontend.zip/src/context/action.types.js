export const WORD = "WORD"
export const REMOVE = "REMOVE"